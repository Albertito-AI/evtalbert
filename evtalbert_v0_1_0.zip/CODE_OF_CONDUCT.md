# Code of Conduct

Be respectful. No harassment or hate speech. Keep discussions technical and on-topic.