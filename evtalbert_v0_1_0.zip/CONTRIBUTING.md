# Contributing

This is a **proprietary, source-available** project. Issues are welcome.
Pull requests may be accepted at the maintainer's discretion.