# EVT‑Albert — Emotional–Volitional Training (Puni‑inspired)

**Status:** stable v0.1.0 · Proprietary © 2025 Tan Sin Hon Albert · Source-available (non-commercial)

EVT‑Albert turns Puni’s emotional‑volitional training into a **trackable**, **auditable** workflow:
- Log sessions with **pre‑start state**, **obstacles**, **regulation** used, outcomes, and a **Volitional Index (VI)**.
- Generate an `analytics.md` dashboard for your repo (auto‑updated by GitHub Actions).
- Export CSV (with optional anonymization) for research.

> This repository is proprietary to **Tan Sin Hon Albert**. See **LICENSE**.

---

## Quickstart

```bash
# 1) Install (editable)
pip install -e .

# 2) Initialize a workspace (creates data/ and config)
evtalbert init --root .

# 3) Log a session
evtalbert log-session   --athlete "albert"   --sport "moot-court"   --task "hot-seat rebuttal (6 min)"   --pre-state fever   --regulation "box-breath 4-2-6 + cue: quiet-hands"   --sec-to-target 35   --obstacle "hostile-judge-question:unexpected"   --outcome success   --rpe 7   --v "purposefulness=4,persistence=5,self_control=4,decisiveness=4"   --notes "first minute shaky; settled after breath and hand anchors"   --root .

# 4) Build the report
evtalbert report --root .

# 5) Export CSV (anonymized)
evtalbert export --root . --path data/evtalbert_logs.csv --anonymize
```

> **Data hygiene:** Raw logs live at `data/logs/logs.jsonl` and are **.gitignored** by default.
> The published artifact is `data/logs/analytics.md`. Change this policy in `config.json`.

---

## Commands

- `evtalbert init [--root DIR]` — create `data/` and `config.json` (with salted hashing for anonymization).
- `evtalbert log-session ...` — append a structured log entry (see options `--pre-state`, `--outcome`, `--v`).
- `evtalbert report [--root DIR]` — compute KPIs and write `data/logs/analytics.md`.
- `evtalbert export --path FILE [--anonymize] [--root DIR]` — CSV export.
- `evtalbert synthetic [--n 30] [--root DIR]` — generate synthetic demo data.

Run `evtalbert -h` or `evtalbert <command> -h` for full help.

---

## KPIs

- **Readiness Ratio** — share of sessions starting in *operational alertness*.
- **Avg Seconds to Target** — time to dial your optimal state.
- **Outcome Mix** — success/partial/failure distribution.
- **Volitional Index (VI)** — rolling 7‑session mean of purposefulness, persistence, self_control, decisiveness.
- **Obstacle Frequency** — top stressors trained.

---

## Automation (GitHub Actions)

- `.github/workflows/ci.yml` — installs package and runs smoke tests.
- `.github/workflows/report.yml` — every Monday 06:00 UTC, runs `evtalbert report` and commits `analytics.md` if changed.

You must push this repository to GitHub for Actions to run.
If using a private repo, ensure `GITHUB_TOKEN` has permission to write contents.

---

## Ethics & Privacy

- Consent, scope, retention: see `docs/ethics.md`.
- Keep raw logs private. Share only aggregates or anonymized exports.

---

## Citation

If you cite this work in academic writing:

- **CITATION.cff** included (supports GitHub's "Cite this repository").

---

## Legal

- Proprietary, source‑available, non‑commercial use only by default. For commercial licensing, contact **s.h.a.tan@rug.nl**.
- Copyright © 2025 **Tan Sin Hon Albert**.