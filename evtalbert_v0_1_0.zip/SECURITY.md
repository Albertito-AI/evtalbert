# Security Policy

Report vulnerabilities to s.h.a.tan@rug.nl. Please allow 30 days for a response.