# Ethics & Privacy

- **Consent**: Ensure individuals whose data you log have given informed consent.
- **Minimization**: Log only what is necessary to improve performance (avoid medical specifics).
- **Retention**: Define a retention period and purge schedules.
- **Access**: Keep raw logs private; publish only aggregates (`analytics.md`) or anonymized exports.
- **Attribution**: When redistributing reports or analyses, attribute to © Tan Sin Hon Albert.